package com.example.registration.preference;

public class Consts {

    public static String IS_REGISTERED = "ISREGISTERED";
    public static String USER_EXTRA = "USER_EXTRA";

}
